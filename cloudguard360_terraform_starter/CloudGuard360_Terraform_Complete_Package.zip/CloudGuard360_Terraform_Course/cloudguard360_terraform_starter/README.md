# CloudGuard 360 — Azure Hub-and-Spoke Terraform Starter

**Start with `../terraform.md` or `../index.html` for the complete English, step-by-step walkthrough.**

This revised starter includes the safe region-recovery design for accounts receiving `RequestDisallowedByAzure` in `westeurope`:

- `location = "northeurope"` locates the **VNets and NSG** in North Europe (subject to subscription eligibility).
- `resource_group_location = "westeurope"` preserves the **metadata location of existing Resource Groups** from the earlier deployment.
- A Resource Group can contain resources in a different Azure region. Changing a Resource Group's own location in Terraform forces replacement, and can delete contained resources.
- **Never overwrite or delete an existing `terraform.tfstate`.** The download is a source configuration and documentation package, not a migrated state.
- `scripts/repair_existing_lab.sh` can patch your original extracted source files **in place** after validating the exact expected structures, creating backups first. Run from the original work folder (see guide).

Resources: 2 Resource Groups, 2 VNets, 3 subnets, 1 NSG, 1 NSG association, 2 VNet peerings; **11 Terraform-managed resources** for a clean deployment.

No compute, AKS, Firewall, public IP, or VM. Verify region and Azure credit before apply. Peering data transfer and Cloud Shell storage can be chargeable.

Default workflow from the project's folder:

```bash
export ARM_SUBSCRIPTION_ID="$(az account show --query id -o tsv)"
cp terraform.tfvars.example terraform.tfvars
terraform fmt -recursive
terraform init
terraform validate
terraform plan -out=step01-reviewed.tfplan
python3 scripts/check_plan.py step01-reviewed.tfplan
# Review, confirm cost/region and assess potential deletes before:
# terraform apply step01-reviewed.tfplan
```

Use the guidance in `../terraform.md` for partial-failure recovery, portal steps, verification and cleanup.
