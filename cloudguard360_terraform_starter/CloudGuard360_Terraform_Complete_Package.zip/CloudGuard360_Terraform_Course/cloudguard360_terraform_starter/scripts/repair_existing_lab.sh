#!/usr/bin/env bash
# CloudGuard 360: idempotent source-only region fix. Run from EXISTING Terraform work directory.
set -euo pipefail
REGION="${1:-northeurope}"
[[ "$REGION" =~ ^[a-z][a-z0-9]+$ ]] || { echo 'ERROR: invalid Azure location identifier'; exit 2; }
for file in main.tf network.tf variables.tf terraform.tfvars; do
  [[ -f "$file" ]] || { echo "ERROR: missing $file. Run from the original Terraform project directory."; exit 2; }
done
[[ -f terraform.tfstate ]] || { echo 'ERROR: local terraform.tfstate not found. STOP and investigate your state location first.'; exit 2; }
[[ "$PWD" == "$HOME"/clouddrive/* ]] || { echo 'ERROR: working directory is not under mounted ~/clouddrive; use the persistent working folder.'; exit 2; }
mountpoint -q "$HOME/clouddrive" || { echo 'ERROR: Cloud Shell clouddrive not mounted.'; exit 2; }
mkdir -p "$HOME/clouddrive/cloudguard360/backups"
umask 077
stamp="$(date -u +%Y%m%dT%H%M%SZ)"
backup="$HOME/clouddrive/cloudguard360/backups/pre-region-repair-$stamp"
mkdir -m 700 "$backup"
for file in main.tf network.tf variables.tf terraform.tfvars terraform.tfstate; do cp -p "$file" "$backup/$file"; done
python3 - "$REGION" <<'PY2'
from pathlib import Path
import re,sys
region=sys.argv[1]
main=Path('main.tf').read_text()
network=Path('network.tf').read_text()
variables=Path('variables.tf').read_text()
values=Path('terraform.tfvars').read_text()
# verify paths before any write to avoid silently modifying divergent code
if 'location = var.location' in main:
    newmain=main.replace('location = var.location','location = var.resource_group_location')
elif 'location = var.resource_group_location' in main:
    newmain=main
else:
    raise SystemExit('ERROR: unexpected main.tf; no files modified.')
oldhub='location            = azurerm_resource_group.network.location'
oldapp='location            = azurerm_resource_group.app.location'
if oldhub in network or oldapp in network:
    newnetwork=network.replace(oldhub,'location            = var.location').replace(oldapp,'location            = var.location')
elif 'location            = var.location' in network:
    newnetwork=network
else:
    raise SystemExit('ERROR: unexpected network.tf; no files modified.')
if 'variable "resource_group_location"' not in variables:
    variables += '\nvariable "resource_group_location" {\n  description = "Existing Resource Groups metadata location; do not change after partial apply."\n  type = string\n  default = "westeurope"\n}\n'
# preserve existing resource group metadata location in original plan
match=re.search(r'(?m)^\s*location\s*=\s*"([a-z0-9]+)"\s*$',values)
if not match: raise SystemExit('ERROR: expected location entry not found in terraform.tfvars; no files modified.')
values = values[:match.start(1)]+region+values[match.end(1):]
if re.search(r'(?m)^\s*resource_group_location\s*=',values):
    values=re.sub(r'(?m)^(\s*resource_group_location\s*=\s*)"[^"]+"',r'\g<1>"westeurope"',values)
else:
    values += '\nresource_group_location = "westeurope"\n'
Path('main.tf').write_text(newmain)
Path('network.tf').write_text(newnetwork)
Path('variables.tf').write_text(variables)
Path('terraform.tfvars').write_text(values)
print(f'Updated network location to {region}; preserved existing Resource Groups in westeurope.')
PY2
terraform fmt -recursive >/dev/null
echo "Backup folder: $backup (contains sensitive state; keep private)"
echo 'NEXT: terraform validate && terraform plan -out=step01-region-recovery.tfplan'
echo 'STOP: inspect the plan before any apply; no resources have been changed.'
