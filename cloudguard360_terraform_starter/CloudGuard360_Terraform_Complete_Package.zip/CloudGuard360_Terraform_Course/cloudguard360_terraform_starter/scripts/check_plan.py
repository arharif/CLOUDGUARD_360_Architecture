#!/usr/bin/env python3
"""Human-readable Terraform plan actions; fail closed on Resource Group deletion."""
import json, subprocess, sys
if len(sys.argv)!=2:
    print('Usage: python3 scripts/check_plan.py PATH_TO_PLAN',file=sys.stderr);sys.exit(2)
command=['terraform','show','-json',sys.argv[1]]
try:
    doc=json.loads(subprocess.check_output(command, text=True))
except (subprocess.CalledProcessError, json.JSONDecodeError) as exc:
    print(f'Could not read plan: {exc}',file=sys.stderr);sys.exit(2)
resources=doc.get('resource_changes',[])
if not resources: print('No resource changes in plan.')
stop=False
for r in resources:
    address=r.get('address','?'); actions=r.get('change',{}).get('actions',[])
    if actions == ['no-op']: continue
    print(f"{','.join(actions):16s} {address}")
    if 'delete' in actions and r.get('type')=='azurerm_resource_group':
        stop=True
if stop:
    print('\nSTOP: One or more Resource Groups would be destroyed/replaced. Do not apply.\n'
          'Re-check resource_group_location and compare with the currently deployed Resource Groups.')
    sys.exit(3)
if any('delete' in r.get('change',{}).get('actions',[]) for r in resources):
    print('\nREVIEW: This plan has deletion/replacement actions. Verify every listed resource before applying.')
else:
    print('\nNo delete actions found. Still verify subscription, region, costs and full plan before apply.')
