variable "prefix" {
  description = "Short, lowercase prefix used for the laboratory resources."
  type        = string
  default     = "cg360"

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{1,14}$", var.prefix))
    error_message = "prefix must be 2-15 lowercase characters, numbers or hyphens, starting with a letter."
  }
}

variable "location" {
  description = "Azure region for the VNets and NSG (must be allowed for this subscription)."
  type        = string
  default     = "northeurope"
}

variable "tags" {
  description = "Common tags applied to resources that support tagging."
  type        = map(string)
  default = {
    project     = "CloudGuard360"
    environment = "lab"
    managed_by  = "terraform"
  }
}

# IMPORTANT: Keep this unchanged when repairing a failed apply that already
# created Resource Groups in West Europe. Azure Resource Group metadata location
# may differ from the location of the resources within the group.
variable "resource_group_location" {
  description = "Location of the resource groups; keep westeurope for existing partial labs."
  type        = string
  default     = "westeurope"
}
